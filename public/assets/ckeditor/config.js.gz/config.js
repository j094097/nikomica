CKEDITOR.config.toolbar= [
  { name: 'styles', items : [ 'Styles','Format' ] },
  { name: 'basicstyles', items : [ 'Bold','Italic','Strike','-','RemoveFormat' ] },
  { name: 'insert', items : [ 'Image', 'Table']},
  '/',
  { name: 'clipboard', items : [ 'Cut','Copy','Paste','PasteText','PasteFromWord','-','Undo','Redo' ] },
  { name: 'editing', items : [ 'Find','Replace','-','SelectAll','-','Scayt' ] },
  { name: 'links', items : [ 'Link','Unlink','Anchor' ] },
  { name: 'tools', items : [ 'Maximize','-','About' ] }
]
;
